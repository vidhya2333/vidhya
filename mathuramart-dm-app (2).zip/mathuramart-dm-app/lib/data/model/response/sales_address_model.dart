class AddressModel {
  final int id;
  final String addressType;
  final String contactPersonNumber; // Change the type to String
  final String address;

  AddressModel({
    required this.id,
    required this.addressType,
    required this.contactPersonNumber,
    required this.address,
  });

  factory AddressModel.fromJson(Map<String, dynamic> json) {
    return AddressModel(
      id: json['id'],
      addressType: json['address_type'],
      contactPersonNumber: json['contact_person_number'],
      address: json['address'],
    );
  }
}
