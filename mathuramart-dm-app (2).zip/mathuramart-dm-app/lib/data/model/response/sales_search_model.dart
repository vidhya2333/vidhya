import 'dart:convert';

SalesSearchModel searchModelFromJson(String str) => SalesSearchModel.fromJson(json.decode(str));

String searchModelToJson(SalesSearchModel data) => json.encode(data.toJson());

class SalesSearchModel {
    Name name;

    SalesSearchModel({
        required this.name,
    });

    factory SalesSearchModel.fromJson(Map<String, dynamic> json) => SalesSearchModel(
        name: Name.fromJson(json["name"]),
    );

    Map<String, dynamic> toJson() => {
        "name": name.toJson(),
    };
}

class Name {
    int id;
    String fName;

    Name({
        required this.id,
        required this.fName,
    });

    factory Name.fromJson(Map<String, dynamic> json) => Name(
        id: json["id"],
        fName: json["f_name"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "f_name": fName,
    };
}