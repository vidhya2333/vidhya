import 'dart:convert';

List<ProductModel> productModelFromJson(String str) => List<ProductModel>.from(
    json.decode(str).map((x) => ProductModel.fromJson(x)));

String productModelToJson(List<ProductModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ProductModel {
  int id;
  String name;
  String description;
  String image;
  int categoryId;
  String categoryIds;
  String variations;
  String addOns;
  String attributes;
  String choiceOptions;
  int price;
  int tax;
  String taxType;
  int discount;
  String discountType;
  String? availableTimeStarts;
  String? availableTimeEnds;
  int veg;
  int status;
  int storeId;
  DateTime createdAt;
  DateTime? updatedAt;
  int orderCount;
  int avgRating;
  int ratingCount;
  dynamic rating;
  int moduleId;
  int stock;
  int unitId;
  List<String> images;
  String foodVariations;
  String slug;
  int recommended;
  int organic;
  int maximumCartQuantity;
  int isApproved;
  double? cgst;
  double? sgst;
  int? igst;
  dynamic gst;
  int purchasePrice;
  String? unitType;
  List<Translation> translations;
  Unit? unit;

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.image,
    required this.categoryId,
    required this.categoryIds,
    required this.variations,
    required this.addOns,
    required this.attributes,
    required this.choiceOptions,
    required this.price,
    required this.tax,
    required this.taxType,
    required this.discount,
    required this.discountType,
    required this.availableTimeStarts,
    required this.availableTimeEnds,
    required this.veg,
    required this.status,
    required this.storeId,
    required this.createdAt,
    required this.updatedAt,
    required this.orderCount,
    required this.avgRating,
    required this.ratingCount,
    required this.rating,
    required this.moduleId,
    required this.stock,
    required this.unitId,
    required this.images,
    required this.foodVariations,
    required this.slug,
    required this.recommended,
    required this.organic,
    required this.maximumCartQuantity,
    required this.isApproved,
    required this.cgst,
    required this.sgst,
    required this.igst,
    required this.gst,
    required this.purchasePrice,
    required this.unitType,
    required this.translations,
    required this.unit,
  });

  factory ProductModel.fromJson(Map<String, dynamic> json) => ProductModel(
        id: json["id"],
        name: json["name"],
        description: json["description"],
        image: json["image"],
        categoryId: json["category_id"],
        categoryIds: json["category_ids"],
        variations: json["variations"],
        addOns: json["add_ons"],
        attributes: json["attributes"],
        choiceOptions: json["choice_options"],
        price: json["price"],
        tax: json["tax"],
        taxType: json["tax_type"],
        discount: json["discount"],
        discountType: json["discount_type"],
        availableTimeStarts: json["available_time_starts"],
        availableTimeEnds: json["available_time_ends"],
        veg: json["veg"],
        status: json["status"],
        storeId: json["store_id"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        orderCount: json["order_count"],
        avgRating: json["avg_rating"],
        ratingCount: json["rating_count"],
        rating: json["rating"],
        moduleId: json["module_id"],
        stock: json["stock"],
        unitId: json["unit_id"],
        images: List<String>.from(json["images"].map((x) => x)),
        foodVariations: json["food_variations"],
        slug: json["slug"],
        recommended: json["recommended"],
        organic: json["organic"],
        maximumCartQuantity: json["maximum_cart_quantity"],
        isApproved: json["is_approved"],
        cgst: json["cgst"]?.toDouble(),
        sgst: json["sgst"]?.toDouble(),
        igst: json["igst"],
        gst: json["gst"],
        purchasePrice:
            (json["purchase_price"] != null) ? json["purchase_price"] : 0,
        unitType: json["unit_type"],
        translations: List<Translation>.from(
            json["translations"].map((x) => Translation.fromJson(x))),
        unit: json["unit"] == null ? null : Unit.fromJson(json["unit"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "description": description,
        "image": image,
        "category_id": categoryId,
        "category_ids": categoryIds,
        "variations": variations,
        "add_ons": addOns,
        "attributes": attributes,
        "choice_options": choiceOptions,
        "price": price,
        "tax": tax,
        "tax_type": taxType,
        "discount": discount,
        "discount_type": discountType,
        "available_time_starts": availableTimeStarts,
        "available_time_ends": availableTimeEnds,
        "veg": veg,
        "status": status,
        "store_id": storeId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "order_count": orderCount,
        "avg_rating": avgRating,
        "rating_count": ratingCount,
        "rating": rating,
        "module_id": moduleId,
        "stock": stock,
        "unit_id": unitId,
        "images": List<dynamic>.from(images.map((x) => x)),
        "food_variations": foodVariations,
        "slug": slug,
        "recommended": recommended,
        "organic": organic,
        "maximum_cart_quantity": maximumCartQuantity,
        "is_approved": isApproved,
        "cgst": cgst,
        "sgst": sgst,
        "igst": igst,
        "gst": gst,
        "purchase_price": purchasePrice,
        "unit_type": unitType,
        "translations": List<dynamic>.from(translations.map((x) => x.toJson())),
        "unit": unit?.toJson(),
      };
}

class Translation {
  int id;
  String translationableType;
  int translationableId;
  String locale;
  String key;
  String value;
  dynamic createdAt;
  dynamic updatedAt;

  Translation({
    required this.id,
    required this.translationableType,
    required this.translationableId,
    required this.locale,
    required this.key,
    required this.value,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Translation.fromJson(Map<String, dynamic> json) => Translation(
        id: json["id"],
        translationableType: json["translationable_type"],
        translationableId: json["translationable_id"],
        locale: json["locale"],
        key: json["key"],
        value: json["value"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "translationable_type": translationableType,
        "translationable_id": translationableId,
        "locale": locale,
        "key": key,
        "value": value,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}

class Unit {
  int id;
  String unit;
  DateTime createdAt;
  DateTime updatedAt;
  List<dynamic> translations;

  Unit({
    required this.id,
    required this.unit,
    required this.createdAt,
    required this.updatedAt,
    required this.translations,
  });

  factory Unit.fromJson(Map<String, dynamic> json) => Unit(
        id: json["id"],
        unit: json["unit"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        translations: List<dynamic>.from(json["translations"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "unit": unit,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "translations": List<dynamic>.from(translations.map((x) => x)),
      };
}

