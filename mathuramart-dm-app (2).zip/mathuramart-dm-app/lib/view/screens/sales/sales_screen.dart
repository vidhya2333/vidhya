// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:mathura_mart_dman/controller/sales_address_controller.dart';
// import 'package:mathura_mart_dman/controller/sales_product_controller.dart';
// import 'package:mathura_mart_dman/controller/sales_search_controller.dart';
// import 'package:mathura_mart_dman/data/model/response/address_model.dart';
// import 'package:mathura_mart_dman/data/model/response/sales_product_model.dart';

// class Product {
//   final String productName;
//   final String rating;
//   final String price;
//   final String imagePath;

//   Product({
//     required this.productName,
//     required this.rating,
//     required this.price,
//     required this.imagePath,
//   });
// }

// TextEditingController _searchController = TextEditingController();
// List<Map<String, dynamic>> filteredList = [];

// Widget _buildStarRating(double rating) {
//   List<Widget> stars = [];
//   for (int i = 0; i < 5; i++) {
//     IconData iconData = i < rating.floor() ? Icons.star : Icons.star_border;
//     Color iconColor = i < rating.floor() ? Colors.green : Colors.grey;
//     stars.add(Icon(iconData, color: iconColor, size: 20));
//   }
//   return Row(children: stars);
// }

// final List<Map<String, dynamic>> productList = [
//   {
//     'imagePath': 'assets/image/juice.jpg',
//     'title': 'Fresh Juice',
//     'store': 'MathuraMart',
//     'price': '\u20B9 100',
//     'discountedPrice': 'Rs.90',
//     'rating': 5.0,
//   },
//   {
//     'imagePath': 'assets/image/oil.jpg',
//     'title': 'Oil',
//     'store': 'MathuraMart',
//     'price': '\u20B9 1100',
//     'discountedPrice': 'Rs.1000',
//     'rating': 3.0,
//   },
//   {
//     'imagePath': 'assets/image/fruit1.jpg',
//     'title': 'Fruit',
//     'store': 'MathuraMart',
//     'price': '\u20B9 500',
//     'discountedPrice': 'Rs.450',
//     'rating': 1.0,
//   },
// ];

// class SalesScreen extends StatelessWidget {
//   final SalesSearchController searchController =
//       Get.put(SalesSearchController());
//   final AddressController addressController = Get.put(AddressController());
//   final ProductController productController = Get.put(ProductController());

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Search Screen'),
//       ),
//       body: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: TextField(
//                     keyboardType: TextInputType.number,
//                     controller: _searchController,
//                     decoration: InputDecoration(
//                       hintText: 'Enter phone number to search',
//                       labelText: 'Search',
//                       border: OutlineInputBorder(),
//                     ),
//                     onChanged: (text) {
//                       searchController.searchByName(text.trim());
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Obx(() {
//             if (searchController.searchResult.value != null) {
//               final name =
//                   searchController.searchResult.value!.name.fName ?? '';
//               final phoneNumber = _searchController.text.trim();
//               return GestureDetector(
//                 onTap: () async {
//                   await addressController.fetchAddressDataByName(phoneNumber);
//                   final addressData = addressController.addressList;
//                   if (addressData.isNotEmpty) {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                         builder: (context) => ContactDetailsScreen(
//                           name: name,
//                           phoneNumber: phoneNumber,
//                           addresses: addressData,
//                         ),
//                       ),
//                     );
//                   } else {}
//                 },
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Text(
//                     '$name',
//                   ),
//                 ),
//               );
//             } else {
//               return SizedBox();
//             }
//           }),
//         ],
//       ),
//     );
//   }
// }

// class ContactDetailsScreen extends StatefulWidget {
//   final String name;
//   final String phoneNumber;
//   final List<AddressModel> addresses;

//   const ContactDetailsScreen({
//     required this.name,
//     required this.phoneNumber,
//     required this.addresses,
//   });

//   @override
//   _ContactDetailsScreenState createState() => _ContactDetailsScreenState();
// }

// class _ContactDetailsScreenState extends State<ContactDetailsScreen> {
//   List<bool> addButtonClicked = List.filled(productList.length, false);
//   bool showIncrementDecrement = false;
//   List<bool> showIncrementDecrementList = List.generate(
//     productList.length,
//     (index) => false,
//   );

//   List<int> quantityList = List.filled(productList.length, 1);

//   void _incrementQuantity(int index) {
//     setState(() {
//       quantityList[index]++;
//     });
//   }

//   void _decrementQuantity(int index) {
//     setState(() {
//       if (quantityList[index] > 1) {
//         quantityList[index]--;
//       } else {
//         showIncrementDecrementList[index] = false;
//       }
//     });
//   }

//   @override
//   void initState() {
//     super.initState();
//     filteredList.addAll(productList);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Contact Details'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: widget.addresses.map((address) {
//                 return Card(
//                   elevation: 3,
//                   margin: EdgeInsets.symmetric(vertical: 5),
//                   child: Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           'Name: ${widget.name}',
//                           style: TextStyle(fontSize: 18),
//                         ),
//                         Text(
//                           'Address Type: ${address.addressType}',
//                           style: TextStyle(fontSize: 18),
//                         ),
//                         Text(
//                           'Contact Person Number: ${address.contactPersonNumber}',
//                           style: TextStyle(fontSize: 18),
//                         ),
//                         Text(
//                           'Address: ${address.address}',
//                           style: TextStyle(fontSize: 18),
//                         ),
//                         SizedBox(height: 10),
//                       ],
//                     ),
//                   ),
//                 );
//               }).toList(),
//             ),
//             SizedBox(height: 20),
//             Padding(
//               padding: const EdgeInsets.all(10.0),
//               child: TextField(
//                 controller: _searchController,
//                 decoration: InputDecoration(
//                   hintText: 'Search by product name',
//                   labelText: 'Search',
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//             ),
//             Expanded(
//               child: SingleChildScrollView(
//                 child: Column(
//                   children: filteredList.map((product) {
//                     final index = filteredList.indexOf(product);
//                     final showIncrementDecrement =
//                         showIncrementDecrementList[index];
//                     final quantity = quantityList[index];
//                     return Card(
//                       elevation: 5,
//                       margin: EdgeInsets.all(10),
//                       child: Column(
//                         children: [
//                           ListTile(
//                             leading: Image.asset(product['imagePath']),
//                             title: Text(product['title']),
//                             subtitle: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Text(product['store']),
//                                 _buildStarRating(product['rating']),
//                                 SizedBox(height: 5),
//                                 Row(
//                                   children: [
//                                     Text(
//                                       product['price'],
//                                       style: TextStyle(color: Colors.black),
//                                     ),
//                                     SizedBox(width: 5),
//                                     Text(
//                                       product['discountedPrice'],
//                                       style: TextStyle(
//                                         color: Colors.grey,
//                                         decoration: TextDecoration.lineThrough,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                             trailing: showIncrementDecrement
//                                 ? Row(
//                                     mainAxisAlignment: MainAxisAlignment.end,
//                                     children: [
//                                       IconButton(
//                                         onPressed: () =>
//                                             _decrementQuantity(index),
//                                         icon: const Icon(Icons.remove),
//                                         color: Colors.black,
//                                       ),
//                                       Text(
//                                         quantity.toString(),
//                                         style: const TextStyle(fontSize: 16),
//                                       ),
//                                       IconButton(
//                                         onPressed: () =>
//                                             _incrementQuantity(index),
//                                         icon: const Icon(Icons.add),
//                                         color: Colors.black,
//                                       ),
//                                     ],
//                                   )
//                                 : ElevatedButton(
//                                     onPressed: () {
//                                       setState(() {
//                                         showIncrementDecrementList[index] =
//                                             !showIncrementDecrementList[index];
//                                       });
//                                     },
//                                     child: Text('ADD'),
//                                   ),
//                           ),
//                         ],
//                       ),
//                     );
//                   }).toList(),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }



// // import 'dart:convert';
// // import 'package:flutter/material.dart';
// // import 'package:get/get.dart';
// // import 'package:get/get.dart';
// // import 'package:get/get_connect/http/src/response/response.dart';
// // import 'package:get/get_connect/http/src/response/response.dart';

// // import '../../../controller/sales_search_controller.dart';

// // class Product {
// //   final String productName;
// //   final String rating;
// //   final String price;
// //   final String imagePath;

// //   Product({
// //     required this.productName,
// //     required this.rating,
// //     required this.price,
// //     required this.imagePath,
// //   });
// // }

// // TextEditingController _searchController = TextEditingController();
// // List<Map<String, dynamic>> filteredList = [];

// // Widget _buildStarRating(double rating) {
// //   List<Widget> stars = [];
// //   for (int i = 0; i < 5; i++) {
// //     IconData iconData = i < rating.floor() ? Icons.star : Icons.star;
// //     Color iconColor = i < rating.floor() ? Colors.green : Colors.grey;
// //     stars.add(Icon(iconData, color: iconColor, size: 10));
// //   }
// //   return Row(children: stars);
// // }

// // final List<Map<String, dynamic>> productList = [
// //   {
// //     'imagePath': 'assets/image/juice.jpg',
// //     'title': 'Fresh Juice',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 100',
// //     'discountedPrice': 'Rs.90',
// //     'rating': 5.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/oil.jpg',
// //     'title': 'Oil',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 1100',
// //     'discountedPrice': 'Rs.1000',
// //     'rating': 3.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/fruit1.jpg',
// //     'title': 'Fruit',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 500',
// //     'discountedPrice': 'Rs.450',
// //     'rating': 1.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/juice.jpg',
// //     'title': 'Fresh Juice',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 100',
// //     'discountedPrice': 'Rs.90',
// //     'rating': 5.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/oil.jpg',
// //     'title': 'Oil',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 1100',
// //     'discountedPrice': 'Rs.1000',
// //     'rating': 3.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/fruit1.jpg',
// //     'title': 'Fruit',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 500',
// //     'discountedPrice': 'Rs.450',
// //     'rating': 1.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/juice.jpg',
// //     'title': 'Fresh Juice',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 100',
// //     'discountedPrice': 'Rs.90',
// //     'rating': 5.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/oil.jpg',
// //     'title': 'Oil',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 1100',
// //     'discountedPrice': 'Rs.1000',
// //     'rating': 3.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/fruit1.jpg',
// //     'title': 'Fruit',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 500',
// //     'discountedPrice': 'Rs.450',
// //     'rating': 1.0,
// //   },
// // ];

// // class SalesScreen extends StatelessWidget {
// //   final SalesSearchController searchController = Get.put(SalesSearchController());

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text('Search Screen'),
// //       ),
// //       body: Column(
// //         children: [
// //           Padding(
// //             padding: const EdgeInsets.all(16.0),
// //             child: Row(
// //               children: [
// //                 Expanded(
// //                   child: TextField(
// //                     keyboardType: TextInputType.number,
// //                     controller: searchController.searchController,
// //                     decoration: InputDecoration(
// //                       hintText: 'Enter phone number to search',
// //                       labelText: 'Search',
// //                       border: OutlineInputBorder(),
// //                     ),
// //                     onChanged: (text) {
// //                       searchController.searchByName(text.trim());
// //                     },
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //           Obx(() {
// //             if (searchController.searchResult.value != null) {
// //               return GestureDetector(
// //                 onTap: () {
// //                   Navigator.push(
// //                     context,
// //                     MaterialPageRoute(
// //                       builder: (context) => ContactDetailsScreen(
// //                         name: searchController.searchResult.value!.name.fName,
// //                         number: searchController.searchController.text
// //                             .trim(),
// //                         addressData: {},
// //                       ),
// //                     ),
// //                   );
// //                 },
// //                 child: Padding(
// //                   padding: const EdgeInsets.all(16.0),
// //                   child: Text(
// //                     '${searchController.searchResult.value!.name.fName}',
// //                   ),
// //                 ),
// //               );
// //             } else {
// //               return SizedBox();
// //             }
// //           }),
// //         ],
// //       ),
// //     );
// //   }
// // }

// // class ContactDetailsScreen extends StatefulWidget {
// //   final String name;
// //   final String number;
// //   final Map<String, String> addressData;

// //   const ContactDetailsScreen({
// //     Key? key,
// //     required this.name,
// //     required this.number,
// //     required this.addressData,
// //   }) : super(key: key);

// //   @override
// //   _ContactDetailsScreenState createState() => _ContactDetailsScreenState();
// // }

// // class _ContactDetailsScreenState extends State<ContactDetailsScreen> {
// //   List<bool> addButtonClicked = List.filled(productList.length, false);
// //   bool showIncrementDecrement = false;
// //   List<bool> showIncrementDecrementList = List.generate(
// //     productList.length,
// //     (index) => false,
// //   );

// //   List<int> quantityList = List.filled(productList.length, 1);

// //   void _incrementQuantity(int index) {
// //     setState(() {
// //       quantityList[index]++;
// //     });
// //   }

// //   void _decrementQuantity(int index) {
// //     setState(() {
// //       if (quantityList[index] > 1) {
// //         quantityList[index]--;
// //       } else {
// //         showIncrementDecrementList[index] = false;
// //       }
// //     });
// //   }

// //   String? selectedAddressType;
// //   @override
// //   void initState() {
// //     super.initState();
// //     filteredList.addAll(productList);
// //   }

// //   void _filterSearchResults(String query) {
// //     if (query.isNotEmpty) {
// //       setState(() {
// //         filteredList = productList
// //             .where((product) =>
// //                 product['title'].toLowerCase().contains(query.toLowerCase()))
// //             .toList();
// //       });
// //     } else {
// //       setState(() {
// //         filteredList.clear();
// //         filteredList.addAll(productList);
// //       });
// //     }
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         centerTitle: true,
// //         title: Text('Sales'),
// //         actions: [
// //           Icon(Icons.shopping_cart),
// //           SizedBox(
// //             width: 10,
// //           )
// //         ],
// //       ),
// //       body: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: [
// //           Padding(
// //             padding: const EdgeInsets.all(5.0),
// //             child: Card(
// //               child: Padding(
// //                 padding: const EdgeInsets.all(8.0),
// //                 child: Column(
// //                   crossAxisAlignment: CrossAxisAlignment.start,
// //                   children: [
// //                     Text(
// //                       'Name: ${widget.name}',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                     Text(
// //                       'Number: ${widget.number}',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                     Row(
// //                       children: [
// //                          Text(
// //                       'Address Types:',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                     Text(
// //                       'Home',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                       ],
// //                     ),
                   
                    
// //                     Text(
// //                       'Address: ${selectedAddressType != null ? widget.addressData[selectedAddressType!] : "Select an address type"}',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //             ),
// //           ),
// //           Padding(
// //             padding: const EdgeInsets.all(10.0),
// //             child: TextField(
// //               controller: _searchController,
// //               onChanged: _filterSearchResults,
// //               decoration: InputDecoration(
// //                 hintText: 'Search by product name',
// //                 labelText: 'Search',
// //                 border: OutlineInputBorder(),
// //               ),
// //             ),
// //           ),
// //           Expanded(
// //             child: SingleChildScrollView(
// //               child: Column(
// //                 children: filteredList.map((product) {
// //                   final index = filteredList.indexOf(product);
// //                   final showIncrementDecrement =
// //                       showIncrementDecrementList[index];
// //                   final quantity = quantityList[index];
// //                   return Card(
// //                     elevation: 5,
// //                     margin: EdgeInsets.all(10),
// //                     child: Column(
// //                       children: [
// //                         ListTile(
// //                           leading: Image.asset(product['imagePath']),
// //                           title: Text(product['title']),
// //                           subtitle: Column(
// //                             crossAxisAlignment: CrossAxisAlignment.start,
// //                             children: [
// //                               Text(product['store']),
// //                               _buildStarRating(product['rating']),
// //                               SizedBox(height: 5),
// //                               Row(
// //                                 children: [
// //                                   Text(
// //                                     product['price'],
// //                                     style: TextStyle(color: Colors.black),
// //                                   ),
// //                                   SizedBox(width: 5),
// //                                   Text(
// //                                     product['discountedPrice'],
// //                                     style: TextStyle(
// //                                       color: Colors.grey,
// //                                       decoration: TextDecoration.lineThrough,
// //                                     ),
// //                                   ),
// //                                 ],
// //                               ),
// //                             ],
// //                           ),
// //                           trailing: showIncrementDecrement
// //                               ? Row(
// //                                   mainAxisAlignment: MainAxisAlignment.end,
// //                                   children: [
// //                                     IconButton(
// //                                       onPressed: () =>
// //                                           _decrementQuantity(index),
// //                                       icon: const Icon(Icons.remove),
// //                                       color: Colors.black,
// //                                     ),
// //                                     Text(
// //                                       quantity.toString(),
// //                                       style: const TextStyle(fontSize: 16),
// //                                     ),
// //                                     IconButton(
// //                                       onPressed: () =>
// //                                           _incrementQuantity(index),
// //                                       icon: const Icon(Icons.add),
// //                                       color: Colors.black,
// //                                     ),
// //                                   ],
// //                                 )
// //                               : ElevatedButton(
// //                                   onPressed: () {
// //                                     setState(() {
// //                                       showIncrementDecrementList[index] =
// //                                           !showIncrementDecrementList[index];
// //                                     });
// //                                   },
// //                                   child: Text('ADD'),
// //                                 ),
// //                         ),
// //                       ],
// //                     ),
// //                   );
// //                 }).toList(),
// //               ),
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }

// // void main() {
// //   runApp(MaterialApp(
// //     home: SalesScreen(),
// //   ));
// // }
// // import 'dart:convert';
// // import 'package:flutter/material.dart';
// // import 'package:get/get.dart';
// // import 'package:get/get.dart';
// // import 'package:get/get_connect/http/src/response/response.dart';
// // import 'package:get/get_connect/http/src/response/response.dart';

// // import '../../../controller/sales_address_controller.dart';
// // import '../../../controller/sales_search_controller.dart';


// // class Product {
// //   final String productName;
// //   final String rating;
// //   final String price;
// //   final String imagePath;

// //   Product({
// //     required this.productName,
// //     required this.rating,
// //     required this.price,
// //     required this.imagePath,
// //   });
// // }

// // TextEditingController _searchController = TextEditingController();
// // List<Map<String, dynamic>> filteredList = [];

// // Widget _buildStarRating(double rating) {
// //   List<Widget> stars = [];
// //   for (int i = 0; i < 5; i++) {
// //     IconData iconData = i < rating.floor() ? Icons.star : Icons.star;
// //     Color iconColor = i < rating.floor() ? Colors.green : Colors.grey;
// //     stars.add(Icon(iconData, color: iconColor, size: 10));
// //   }
// //   return Row(children: stars);
// // }

// // final List<Map<String, dynamic>> productList = [
// //   {
// //     'imagePath': 'assets/image/juice.jpg',
// //     'title': 'Fresh Juice',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 100',
// //     'discountedPrice': 'Rs.90',
// //     'rating': 5.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/oil.jpg',
// //     'title': 'Oil',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 1100',
// //     'discountedPrice': 'Rs.1000',
// //     'rating': 3.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/fruit1.jpg',
// //     'title': 'Fruit',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 500',
// //     'discountedPrice': 'Rs.450',
// //     'rating': 1.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/juice.jpg',
// //     'title': 'Fresh Juice',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 100',
// //     'discountedPrice': 'Rs.90',
// //     'rating': 5.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/oil.jpg',
// //     'title': 'Oil',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 1100',
// //     'discountedPrice': 'Rs.1000',
// //     'rating': 3.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/fruit1.jpg',
// //     'title': 'Fruit',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 500',
// //     'discountedPrice': 'Rs.450',
// //     'rating': 1.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/juice.jpg',
// //     'title': 'Fresh Juice',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 100',
// //     'discountedPrice': 'Rs.90',
// //     'rating': 5.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/oil.jpg',
// //     'title': 'Oil',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 1100',
// //     'discountedPrice': 'Rs.1000',
// //     'rating': 3.0,
// //   },
// //   {
// //     'imagePath': 'assets/image/fruit1.jpg',
// //     'title': 'Fruit',
// //     'store': 'MathuraMart',
// //     'price': '\u20B9 500',
// //     'discountedPrice': 'Rs.450',
// //     'rating': 1.0,
// //   },
// // ];

// // class Sales_screen extends StatelessWidget {
// //   final Sales_Search_Controller searchController = Get.put(Sales_Search_Controller());

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text('Search Screen'),
// //       ),
// //       body: Column(
// //         children: [
// //           Padding(
// //             padding: const EdgeInsets.all(16.0),
// //             child: Row(
// //               children: [
// //                 Expanded(
// //                   child: TextField(
// //                     keyboardType: TextInputType.number,
// //                     controller: searchController.searchController,
// //                     decoration: InputDecoration(
// //                       hintText: 'Enter phone number to search',
// //                       labelText: 'Search',
// //                       border: OutlineInputBorder(),
// //                     ),
// //                     onChanged: (text) {
// //                       searchController.searchByName(text.trim());
// //                     },
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //           Obx(() {
// //             if (searchController.searchResult.value != null) {
// //               return GestureDetector(
// //                 onTap: () {
// //                   Navigator.push(
// //                     context,
// //                     MaterialPageRoute(
// //                       builder: (context) => ContactDetailsScreen(
// //                         name: searchController.searchResult.value!.name.fName,
// //                         number: searchController.searchController.text.trim(),
// //                         addressData: {},
// //                       ),
// //                     ),
// //                   );
// //                 },
// //                 child: Padding(
// //                   padding: const EdgeInsets.all(16.0),
// //                   child: Text(
// //                     '${searchController.searchResult.value!.name.fName}',
// //                   ),
// //                 ),
// //               );
// //             } else {
// //               return SizedBox();
// //             }
// //           }),
// //         ],
// //       ),
// //     );
// //   }
// // }

// // class ContactDetailsScreen extends StatefulWidget {
// //   final String name;
// //   final String number;
// //   final Map<String, String> addressData;

// //   const ContactDetailsScreen({
// //     Key? key,
// //     required this.name,
// //     required this.number,
// //     required this.addressData,
// //   }) : super(key: key);

// //   @override
// //   _ContactDetailsScreenState createState() => _ContactDetailsScreenState();
// // }

// // class _ContactDetailsScreenState extends State<ContactDetailsScreen> {
// //   final SalesAddressController salesAddressController = Get.put(SalesAddressController()); 
// //   List<bool> addButtonClicked = List.filled(productList.length, false);
// //   bool showIncrementDecrement = false;
// //   List<bool> showIncrementDecrementList = List.generate(
// //     productList.length,
// //     (index) => false,
// //   );

// //   List<int> quantityList = List.filled(productList.length, 1);

// //   void _incrementQuantity(int index) {
// //     setState(() {
// //       quantityList[index]++;
// //     });
// //   }

// //   void _decrementQuantity(int index) {
// //     setState(() {
// //       if (quantityList[index] > 1) {
// //         quantityList[index]--;
// //       } else {
// //         showIncrementDecrementList[index] = false;
// //       }
// //     });
// //   }

// //   @override
// //   void initState() {
// //     super.initState();
// //     filteredList.addAll(productList);
// //   }

// //   void _filterSearchResults(String query) {
// //     if (query.isNotEmpty) {
// //       setState(() {
// //         filteredList = productList
// //             .where((product) =>
// //                 product['title'].toLowerCase().contains(query.toLowerCase()))
// //             .toList();
// //       });
// //     } else {
// //       setState(() {
// //         filteredList.clear();
// //         filteredList.addAll(productList);
// //       });
// //     }
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     // addressController.fetchAddressData('home');
// //     return Scaffold(
// //       appBar: AppBar(
// //         centerTitle: true,
// //         title: Text('Sales'),
// //         actions: [
// //           Icon(Icons.shopping_cart),
// //           SizedBox(
// //             width: 10,
// //           )
// //         ],
// //       ),
// //       body: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: [
// //          Padding(
// //   padding: const EdgeInsets.all(16.0),
// //   child: Card(
// //     child: Padding(
// //       padding: const EdgeInsets.all(8.0),
// //       child: Column(
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: [
// //           Obx(
// //             () {
// //               if (salesAddressController.addressList.isNotEmpty) {
// //                 return Column(
// //                   crossAxisAlignment: CrossAxisAlignment.start,
// //                   children: [
// //                     Text(
// //                       'Name: ${widget.name}',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                     SizedBox(height: 8),
// //                     Text(
// //                       'Number: ${widget.number}',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                     SizedBox(height: 8),
// //                     Text(
// //                       'Address Type: Home', 
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                     SizedBox(height: 8),
// //                     Text(
// //                       'Address: ${salesAddressController.addressList.first.address}',
// //                       style: TextStyle(fontSize: 16),
// //                     ),
// //                   ],
// //                 );
// //               } else {
// //                 return Text(
// //                   'No address available for the selected type',
// //                   style: TextStyle(fontSize: 16),
// //                 );
// //               }
// //             },
// //           ),
// //         ],
// //       ),
// //     ),
// //   ),
// // ),

// //           Padding(
// //             padding: const EdgeInsets.all(10.0),
// //             child: TextField(
// //               controller: _searchController,
// //               onChanged: _filterSearchResults,
// //               decoration: InputDecoration(
// //                 hintText: 'Search by product name',
// //                 labelText: 'Search',
// //                 border: OutlineInputBorder(),
// //               ),
// //             ),
// //           ),
// //           Expanded(
// //             child: SingleChildScrollView(
// //               child: Column(
// //                 children: filteredList.map((product) {
// //                   final index = filteredList.indexOf(product);
// //                   final showIncrementDecrement =
// //                       showIncrementDecrementList[index];
// //                   final quantity = quantityList[index];
// //                   return Card(
// //                     elevation: 5,
// //                     margin: EdgeInsets.all(10),
// //                     child: Column(
// //                       children: [
// //                         ListTile(
// //                           leading: Image.asset(product['imagePath']),
// //                           title: Text(product['title']),
// //                           subtitle: Column(
// //                             crossAxisAlignment: CrossAxisAlignment.start,
// //                             children: [
// //                               Text(product['store']),
// //                               _buildStarRating(product['rating']),
// //                               SizedBox(height: 5),
// //                               Row(
// //                                 children: [
// //                                   Text(
// //                                     product['price'],
// //                                     style: TextStyle(color: Colors.black),
// //                                   ),
// //                                   SizedBox(width: 5),
// //                                   Text(
// //                                     product['discountedPrice'],
// //                                     style: TextStyle(
// //                                       color: Colors.grey,
// //                                       decoration: TextDecoration.lineThrough,
// //                                     ),
// //                                   ),
// //                                 ],
// //                               ),
// //                             ],
// //                           ),
// //                           trailing: showIncrementDecrement
// //                               ? Row(
// //                                   mainAxisAlignment: MainAxisAlignment.end,
// //                                   children: [
// //                                     IconButton(
// //                                       onPressed: () =>
// //                                           _decrementQuantity(index),
// //                                       icon: const Icon(Icons.remove),
// //                                       color: Colors.black,
// //                                     ),
// //                                     Text(
// //                                       quantity.toString(),
// //                                       style: const TextStyle(fontSize: 16),
// //                                     ),
// //                                     IconButton(
// //                                       onPressed: () =>
// //                                           _incrementQuantity(index),
// //                                       icon: const Icon(Icons.add),
// //                                       color: Colors.black,
// //                                     ),
// //                                   ],
// //                                 )
// //                               : ElevatedButton(
// //                                   onPressed: () {
// //                                     setState(() {
// //                                       showIncrementDecrementList[index] =
// //                                           !showIncrementDecrementList[index];
// //                                     });
// //                                   },
// //                                   child: Text('ADD'),
// //                                 ),
// //                         ),
// //                       ],
// //                     ),
// //                   );
// //                 }).toList(),
// //               ),
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }
// // }

// // void main() {
// //   runApp(MaterialApp(
// //     home: Sales_screen(),
// //   ));
// // }
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mathura_mart_dman/controller/sales_address_controller.dart';
import 'package:mathura_mart_dman/controller/sales_product_controller.dart';
import 'package:mathura_mart_dman/controller/sales_search_controller.dart';
import 'package:mathura_mart_dman/controller/splash_controller.dart';
import 'package:mathura_mart_dman/data/model/response/address_model.dart';
import 'package:mathura_mart_dman/data/model/response/sales_product_model.dart';

List<ProductModel> filteredList = [];

Widget _buildStarRating(double rating) {
  List<Widget> stars = [];
  for (int i = 0; i < 5; i++) {
    IconData iconData = i < rating.floor() ? Icons.star : Icons.star_border;
    Color iconColor = i < rating.floor() ? Colors.green : Colors.grey;
    stars.add(Icon(iconData, color: iconColor, size: 20));
  }
  return Row(children: stars);
}

List<ProductModel> productList = [];

class SalesScreen extends StatefulWidget {
  const SalesScreen({super.key});

  @override
  State<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  TextEditingController _searchController = TextEditingController();
  final SalesSearchController searchController =
      Get.put(SalesSearchController());
  final AddressController addressController = Get.put(AddressController());
  final ProductController productController = Get.put(ProductController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    productList.clear();
    productController.fetchProducts().then(
      (value) {
        // ignore: invalid_use_of_protected_member
        setState(() {
          productList = productController.productList;
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Screen'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: _searchController,
                    decoration: const InputDecoration(
                      hintText: 'Enter phone number to search',
                      labelText: 'Search',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (text) {
                      searchController.searchByName(text.trim());
                    },
                  ),
                ),
              ],
            ),
          ),
          Obx(() {
            if (searchController.searchResult.value != null) {
              final name = searchController.searchResult.value!.name.fName;
              final getId = searchController.searchResult.value!.name.id;
              final phoneNumber = _searchController.text.trim();
              return GestureDetector(
                onTap: () async {
                  await addressController.fetchAddressDataByName(getId);
                  final addressData = addressController.addressList;
                  if (addressData.isNotEmpty) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ContactDetailsScreen(
                          name: name,
                          phoneNumber: phoneNumber,
                          addresses: addressData,
                        ),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("No address found"),
                      ),
                    );
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Click Me : $name',
                    style: const TextStyle(fontSize: 20.0),
                  ),
                ),
              );
            } else {
              return const SizedBox();
            }
          }),
        ],
      ),
    );
  }
}

// class SalesScreen extends StatelessWidget {
//   final SalesSearchController searchController =
//       Get.put(SalesSearchController());
//   final AddressController addressController = Get.put(AddressController());
//   final ProductController productController = Get.put(ProductController());

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Search Screen'),
//       ),
//       body: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: TextField(
//                     keyboardType: TextInputType.number,
//                     controller: _searchController,
//                     decoration: InputDecoration(
//                       hintText: 'Enter phone number to search',
//                       labelText: 'Search',
//                       border: OutlineInputBorder(),
//                     ),
//                     onChanged: (text) {
//                       searchController.searchByName(text.trim());
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Obx(() {
//             if (searchController.searchResult.value != null) {
//               final name =
//                   searchController.searchResult.value!.name.fName ?? '';
//               final phoneNumber = _searchController.text.trim();
//               return GestureDetector(
//                 onTap: () async {
//                   await addressController.fetchAddressDataByName(phoneNumber);
//                   final addressData = addressController.addressList;
//                   if (addressData.isNotEmpty) {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                         builder: (context) => ContactDetailsScreen(
//                           name: name,
//                           phoneNumber: phoneNumber,
//                           addresses: addressData,
//                         ),
//                       ),
//                     );
//                   } else {}
//                 },
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Text(
//                     '$name',
//                   ),
//                 ),
//               );
//             } else {
//               return SizedBox();
//             }
//           }),
//         ],
//       ),
//     );
//   }
// }

class ContactDetailsScreen extends StatefulWidget {
  final String name;
  final String phoneNumber;
  final List<AddressModel> addresses;

  const ContactDetailsScreen({
    required this.name,
    required this.phoneNumber,
    required this.addresses,
  });

  @override
  _ContactDetailsScreenState createState() => _ContactDetailsScreenState();
}

class _ContactDetailsScreenState extends State<ContactDetailsScreen> {
  TextEditingController _searchProductController = TextEditingController();
  List<bool> addButtonClicked = List.filled(productList.length, false);
  bool showIncrementDecrement = false;
  bool isFilterClicked = false;
  List<ProductModel> filterSearchList = [];
  List<bool> showIncrementDecrementList = List.generate(
    productList.length,
    (index) => false,
  );

  List<int> quantityList = List.filled(productList.length, 1);

  void _incrementQuantity(int index) {
    setState(() {
      quantityList[index]++;
    });
  }

  void _decrementQuantity(int index) {
    setState(() {
      if (quantityList[index] > 1) {
        quantityList[index]--;
      } else {
        showIncrementDecrementList[index] = false;
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _searchProductController.text = '';
    filteredList.clear();
    filteredList.addAll(productList);
    showIncrementDecrementList = List.generate(
      productList.length,
      (index) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: widget.addresses.map((address) {
                return Card(
                  elevation: 3,
                  margin: const EdgeInsets.symmetric(vertical: 5),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Name: ${widget.name}',
                          style: const TextStyle(fontSize: 18),
                        ),
                        Text(
                          'Address Type: ${address.addressType}',
                          style: const TextStyle(fontSize: 18),
                        ),
                        Text(
                          'Contact Person Number: ${address.contactPersonNumber}',
                          style: const TextStyle(fontSize: 18),
                        ),
                        Text(
                          'Address: ${address.address}',
                          style: const TextStyle(fontSize: 18),
                        ),
                        const SizedBox(height: 10),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                controller: _searchProductController,
                decoration: const InputDecoration(
                  hintText: 'Search by product name',
                  labelText: 'Search',
                  border: OutlineInputBorder(),
                ),
                onChanged: (text) {
                  if (text.isNotEmpty) {
                    setState(() {
                      isFilterClicked = true;
                      filterSearchList.clear();
                      List<ProductModel> getList = filteredList
                          .where((product) => product.name
                              .toLowerCase()
                              .contains(text.toLowerCase()))
                          .toList();
                      filterSearchList = getList;
                    });
                  } else {
                    setState(() {
                      isFilterClicked = false;
                    });
                  }
                },
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: isFilterClicked
                    ? filterSearchList.length
                    : filteredList.length, // number of items in your list
                itemBuilder: (BuildContext context, int index) {
                  ProductModel product = isFilterClicked
                      ? filterSearchList[index]
                      : filteredList[index];
                  print(
                      '${Get.find<SplashController>().configModel!.baseUrls!.itemImageUrl}/${product.image}');
                  return Card(
                    elevation: 5,
                    margin: EdgeInsets.all(10),
                    child: Column(
                      children: [
                        ListTile(
                          leading: Image.network(
                              width: 50,
                              height: 50,
                              '${Get.find<SplashController>().configModel!.baseUrls!.itemImageUrl}/${product.image}'),
                          title: Text(product.name),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Text(product['store']),
                              _buildStarRating(0),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  Text(
                                    "${product.price}",
                                    style: TextStyle(color: Colors.black),
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    "${product.discount}",
                                    style: const TextStyle(
                                      color: Colors.grey,
                                      decoration: TextDecoration.lineThrough,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          trailing: showIncrementDecrement
                              ? Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    IconButton(
                                      onPressed: () =>
                                          _decrementQuantity(index),
                                      icon: const Icon(Icons.remove),
                                      color: Colors.black,
                                    ),
                                    const Text(
                                      '1',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                    IconButton(
                                      onPressed: () =>
                                          _incrementQuantity(index),
                                      icon: const Icon(Icons.add),
                                      color: Colors.black,
                                    ),
                                  ],
                                )
                              : ElevatedButton(
                                  onPressed: () {
                                    setState(() {
                                      showIncrementDecrementList[index] =
                                          !showIncrementDecrementList[index];
                                    });
                                  },
                                  child: Text('ADD'),
                                ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            )
            // Expanded(
            //   child: SingleChildScrollView(
            //     child: Column(
            //       children: filteredList.map((product) {
            //         final index = filteredList.indexOf(product);
            //         final showIncrementDecrement =
            //             showIncrementDecrementList[index];
            //         final quantity = quantityList[index];
            //         return Card(
            //           elevation: 5,
            //           margin: EdgeInsets.all(10),
            //           child: Column(
            //             children: [
            //               ListTile(
            //                 leading: Image.asset(product.image),
            //                 title: Text(product.name),
            //                 subtitle: Column(
            //                   crossAxisAlignment: CrossAxisAlignment.start,
            //                   children: [
            //                     // Text(product['store']),
            //                     _buildStarRating(0),
            //                     const SizedBox(height: 5),
            //                     Row(
            //                       children: [
            //                         Text(
            //                           "${product.price}",
            //                           style: TextStyle(color: Colors.black),
            //                         ),
            //                         const SizedBox(width: 5),
            //                         Text(
            //                           "${product.discount}",
            //                           style: const TextStyle(
            //                             color: Colors.grey,
            //                             decoration: TextDecoration.lineThrough,
            //                           ),
            //                         ),
            //                       ],
            //                     ),
            //                   ],
            //                 ),
            //                 trailing: showIncrementDecrement
            //                     ? Row(
            //                         mainAxisAlignment: MainAxisAlignment.end,
            //                         children: [
            //                           IconButton(
            //                             onPressed: () =>
            //                                 _decrementQuantity(index),
            //                             icon: const Icon(Icons.remove),
            //                             color: Colors.black,
            //                           ),
            //                           Text(
            //                             quantity.toString(),
            //                             style: const TextStyle(fontSize: 16),
            //                           ),
            //                           IconButton(
            //                             onPressed: () =>
            //                                 _incrementQuantity(index),
            //                             icon: const Icon(Icons.add),
            //                             color: Colors.black,
            //                           ),
            //                         ],
            //                       )
            //                     : ElevatedButton(
            //                         onPressed: () {
            //                           setState(() {
            //                             showIncrementDecrementList[index] =
            //                                 !showIncrementDecrementList[index];
            //                           });
            //                         },
            //                         child: Text('ADD'),
            //                       ),
            //               ),
            //             ],
            //           ),
            //         );
            //       }).toList(),
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}



// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get.dart';
// import 'package:get/get_connect/http/src/response/response.dart';
// import 'package:get/get_connect/http/src/response/response.dart';

// import '../../../controller/sales_search_controller.dart';

// class Product {
//   final String productName;
//   final String rating;
//   final String price;
//   final String imagePath;

//   Product({
//     required this.productName,
//     required this.rating,
//     required this.price,
//     required this.imagePath,
//   });
// }

// TextEditingController _searchController = TextEditingController();
// List<Map<String, dynamic>> filteredList = [];

// Widget _buildStarRating(double rating) {
//   List<Widget> stars = [];
//   for (int i = 0; i < 5; i++) {
//     IconData iconData = i < rating.floor() ? Icons.star : Icons.star;
//     Color iconColor = i < rating.floor() ? Colors.green : Colors.grey;
//     stars.add(Icon(iconData, color: iconColor, size: 10));
//   }
//   return Row(children: stars);
// }

// final List<Map<String, dynamic>> productList = [
//   {
//     'imagePath': 'assets/image/juice.jpg',
//     'title': 'Fresh Juice',
//     'store': 'MathuraMart',
//     'price': '\u20B9 100',
//     'discountedPrice': 'Rs.90',
//     'rating': 5.0,
//   },
//   {
//     'imagePath': 'assets/image/oil.jpg',
//     'title': 'Oil',
//     'store': 'MathuraMart',
//     'price': '\u20B9 1100',
//     'discountedPrice': 'Rs.1000',
//     'rating': 3.0,
//   },
//   {
//     'imagePath': 'assets/image/fruit1.jpg',
//     'title': 'Fruit',
//     'store': 'MathuraMart',
//     'price': '\u20B9 500',
//     'discountedPrice': 'Rs.450',
//     'rating': 1.0,
//   },
//   {
//     'imagePath': 'assets/image/juice.jpg',
//     'title': 'Fresh Juice',
//     'store': 'MathuraMart',
//     'price': '\u20B9 100',
//     'discountedPrice': 'Rs.90',
//     'rating': 5.0,
//   },
//   {
//     'imagePath': 'assets/image/oil.jpg',
//     'title': 'Oil',
//     'store': 'MathuraMart',
//     'price': '\u20B9 1100',
//     'discountedPrice': 'Rs.1000',
//     'rating': 3.0,
//   },
//   {
//     'imagePath': 'assets/image/fruit1.jpg',
//     'title': 'Fruit',
//     'store': 'MathuraMart',
//     'price': '\u20B9 500',
//     'discountedPrice': 'Rs.450',
//     'rating': 1.0,
//   },
//   {
//     'imagePath': 'assets/image/juice.jpg',
//     'title': 'Fresh Juice',
//     'store': 'MathuraMart',
//     'price': '\u20B9 100',
//     'discountedPrice': 'Rs.90',
//     'rating': 5.0,
//   },
//   {
//     'imagePath': 'assets/image/oil.jpg',
//     'title': 'Oil',
//     'store': 'MathuraMart',
//     'price': '\u20B9 1100',
//     'discountedPrice': 'Rs.1000',
//     'rating': 3.0,
//   },
//   {
//     'imagePath': 'assets/image/fruit1.jpg',
//     'title': 'Fruit',
//     'store': 'MathuraMart',
//     'price': '\u20B9 500',
//     'discountedPrice': 'Rs.450',
//     'rating': 1.0,
//   },
// ];

// class SalesScreen extends StatelessWidget {
//   final SalesSearchController searchController = Get.put(SalesSearchController());

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Search Screen'),
//       ),
//       body: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: TextField(
//                     keyboardType: TextInputType.number,
//                     controller: searchController.searchController,
//                     decoration: InputDecoration(
//                       hintText: 'Enter phone number to search',
//                       labelText: 'Search',
//                       border: OutlineInputBorder(),
//                     ),
//                     onChanged: (text) {
//                       searchController.searchByName(text.trim());
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Obx(() {
//             if (searchController.searchResult.value != null) {
//               return GestureDetector(
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => ContactDetailsScreen(
//                         name: searchController.searchResult.value!.name.fName,
//                         number: searchController.searchController.text
//                             .trim(),
//                         addressData: {},
//                       ),
//                     ),
//                   );
//                 },
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Text(
//                     '${searchController.searchResult.value!.name.fName}',
//                   ),
//                 ),
//               );
//             } else {
//               return SizedBox();
//             }
//           }),
//         ],
//       ),
//     );
//   }
// }

// class ContactDetailsScreen extends StatefulWidget {
//   final String name;
//   final String number;
//   final Map<String, String> addressData;

//   const ContactDetailsScreen({
//     Key? key,
//     required this.name,
//     required this.number,
//     required this.addressData,
//   }) : super(key: key);

//   @override
//   _ContactDetailsScreenState createState() => _ContactDetailsScreenState();
// }

// class _ContactDetailsScreenState extends State<ContactDetailsScreen> {
//   List<bool> addButtonClicked = List.filled(productList.length, false);
//   bool showIncrementDecrement = false;
//   List<bool> showIncrementDecrementList = List.generate(
//     productList.length,
//     (index) => false,
//   );

//   List<int> quantityList = List.filled(productList.length, 1);

//   void _incrementQuantity(int index) {
//     setState(() {
//       quantityList[index]++;
//     });
//   }

//   void _decrementQuantity(int index) {
//     setState(() {
//       if (quantityList[index] > 1) {
//         quantityList[index]--;
//       } else {
//         showIncrementDecrementList[index] = false;
//       }
//     });
//   }

//   String? selectedAddressType;
//   @override
//   void initState() {
//     super.initState();
//     filteredList.addAll(productList);
//   }

//   void _filterSearchResults(String query) {
//     if (query.isNotEmpty) {
//       setState(() {
//         filteredList = productList
//             .where((product) =>
//                 product['title'].toLowerCase().contains(query.toLowerCase()))
//             .toList();
//       });
//     } else {
//       setState(() {
//         filteredList.clear();
//         filteredList.addAll(productList);
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: Text('Sales'),
//         actions: [
//           Icon(Icons.shopping_cart),
//           SizedBox(
//             width: 10,
//           )
//         ],
//       ),
//       body: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(5.0),
//             child: Card(
//               child: Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       'Name: ${widget.name}',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                     Text(
//                       'Number: ${widget.number}',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                     Row(
//                       children: [
//                          Text(
//                       'Address Types:',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                     Text(
//                       'Home',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                       ],
//                     ),
                   
                    
//                     Text(
//                       'Address: ${selectedAddressType != null ? widget.addressData[selectedAddressType!] : "Select an address type"}',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: TextField(
//               controller: _searchController,
//               onChanged: _filterSearchResults,
//               decoration: InputDecoration(
//                 hintText: 'Search by product name',
//                 labelText: 'Search',
//                 border: OutlineInputBorder(),
//               ),
//             ),
//           ),
//           Expanded(
//             child: SingleChildScrollView(
//               child: Column(
//                 children: filteredList.map((product) {
//                   final index = filteredList.indexOf(product);
//                   final showIncrementDecrement =
//                       showIncrementDecrementList[index];
//                   final quantity = quantityList[index];
//                   return Card(
//                     elevation: 5,
//                     margin: EdgeInsets.all(10),
//                     child: Column(
//                       children: [
//                         ListTile(
//                           leading: Image.asset(product['imagePath']),
//                           title: Text(product['title']),
//                           subtitle: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text(product['store']),
//                               _buildStarRating(product['rating']),
//                               SizedBox(height: 5),
//                               Row(
//                                 children: [
//                                   Text(
//                                     product['price'],
//                                     style: TextStyle(color: Colors.black),
//                                   ),
//                                   SizedBox(width: 5),
//                                   Text(
//                                     product['discountedPrice'],
//                                     style: TextStyle(
//                                       color: Colors.grey,
//                                       decoration: TextDecoration.lineThrough,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                           trailing: showIncrementDecrement
//                               ? Row(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     IconButton(
//                                       onPressed: () =>
//                                           _decrementQuantity(index),
//                                       icon: const Icon(Icons.remove),
//                                       color: Colors.black,
//                                     ),
//                                     Text(
//                                       quantity.toString(),
//                                       style: const TextStyle(fontSize: 16),
//                                     ),
//                                     IconButton(
//                                       onPressed: () =>
//                                           _incrementQuantity(index),
//                                       icon: const Icon(Icons.add),
//                                       color: Colors.black,
//                                     ),
//                                   ],
//                                 )
//                               : ElevatedButton(
//                                   onPressed: () {
//                                     setState(() {
//                                       showIncrementDecrementList[index] =
//                                           !showIncrementDecrementList[index];
//                                     });
//                                   },
//                                   child: Text('ADD'),
//                                 ),
//                         ),
//                       ],
//                     ),
//                   );
//                 }).toList(),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// void main() {
//   runApp(MaterialApp(
//     home: SalesScreen(),
//   ));
// }
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get.dart';
// import 'package:get/get_connect/http/src/response/response.dart';
// import 'package:get/get_connect/http/src/response/response.dart';

// import '../../../controller/sales_address_controller.dart';
// import '../../../controller/sales_search_controller.dart';


// class Product {
//   final String productName;
//   final String rating;
//   final String price;
//   final String imagePath;

//   Product({
//     required this.productName,
//     required this.rating,
//     required this.price,
//     required this.imagePath,
//   });
// }

// TextEditingController _searchController = TextEditingController();
// List<Map<String, dynamic>> filteredList = [];

// Widget _buildStarRating(double rating) {
//   List<Widget> stars = [];
//   for (int i = 0; i < 5; i++) {
//     IconData iconData = i < rating.floor() ? Icons.star : Icons.star;
//     Color iconColor = i < rating.floor() ? Colors.green : Colors.grey;
//     stars.add(Icon(iconData, color: iconColor, size: 10));
//   }
//   return Row(children: stars);
// }

// final List<Map<String, dynamic>> productList = [
//   {
//     'imagePath': 'assets/image/juice.jpg',
//     'title': 'Fresh Juice',
//     'store': 'MathuraMart',
//     'price': '\u20B9 100',
//     'discountedPrice': 'Rs.90',
//     'rating': 5.0,
//   },
//   {
//     'imagePath': 'assets/image/oil.jpg',
//     'title': 'Oil',
//     'store': 'MathuraMart',
//     'price': '\u20B9 1100',
//     'discountedPrice': 'Rs.1000',
//     'rating': 3.0,
//   },
//   {
//     'imagePath': 'assets/image/fruit1.jpg',
//     'title': 'Fruit',
//     'store': 'MathuraMart',
//     'price': '\u20B9 500',
//     'discountedPrice': 'Rs.450',
//     'rating': 1.0,
//   },
//   {
//     'imagePath': 'assets/image/juice.jpg',
//     'title': 'Fresh Juice',
//     'store': 'MathuraMart',
//     'price': '\u20B9 100',
//     'discountedPrice': 'Rs.90',
//     'rating': 5.0,
//   },
//   {
//     'imagePath': 'assets/image/oil.jpg',
//     'title': 'Oil',
//     'store': 'MathuraMart',
//     'price': '\u20B9 1100',
//     'discountedPrice': 'Rs.1000',
//     'rating': 3.0,
//   },
//   {
//     'imagePath': 'assets/image/fruit1.jpg',
//     'title': 'Fruit',
//     'store': 'MathuraMart',
//     'price': '\u20B9 500',
//     'discountedPrice': 'Rs.450',
//     'rating': 1.0,
//   },
//   {
//     'imagePath': 'assets/image/juice.jpg',
//     'title': 'Fresh Juice',
//     'store': 'MathuraMart',
//     'price': '\u20B9 100',
//     'discountedPrice': 'Rs.90',
//     'rating': 5.0,
//   },
//   {
//     'imagePath': 'assets/image/oil.jpg',
//     'title': 'Oil',
//     'store': 'MathuraMart',
//     'price': '\u20B9 1100',
//     'discountedPrice': 'Rs.1000',
//     'rating': 3.0,
//   },
//   {
//     'imagePath': 'assets/image/fruit1.jpg',
//     'title': 'Fruit',
//     'store': 'MathuraMart',
//     'price': '\u20B9 500',
//     'discountedPrice': 'Rs.450',
//     'rating': 1.0,
//   },
// ];

// class Sales_screen extends StatelessWidget {
//   final Sales_Search_Controller searchController = Get.put(Sales_Search_Controller());

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Search Screen'),
//       ),
//       body: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(16.0),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: TextField(
//                     keyboardType: TextInputType.number,
//                     controller: searchController.searchController,
//                     decoration: InputDecoration(
//                       hintText: 'Enter phone number to search',
//                       labelText: 'Search',
//                       border: OutlineInputBorder(),
//                     ),
//                     onChanged: (text) {
//                       searchController.searchByName(text.trim());
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Obx(() {
//             if (searchController.searchResult.value != null) {
//               return GestureDetector(
//                 onTap: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => ContactDetailsScreen(
//                         name: searchController.searchResult.value!.name.fName,
//                         number: searchController.searchController.text.trim(),
//                         addressData: {},
//                       ),
//                     ),
//                   );
//                 },
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Text(
//                     '${searchController.searchResult.value!.name.fName}',
//                   ),
//                 ),
//               );
//             } else {
//               return SizedBox();
//             }
//           }),
//         ],
//       ),
//     );
//   }
// }

// class ContactDetailsScreen extends StatefulWidget {
//   final String name;
//   final String number;
//   final Map<String, String> addressData;

//   const ContactDetailsScreen({
//     Key? key,
//     required this.name,
//     required this.number,
//     required this.addressData,
//   }) : super(key: key);

//   @override
//   _ContactDetailsScreenState createState() => _ContactDetailsScreenState();
// }

// class _ContactDetailsScreenState extends State<ContactDetailsScreen> {
//   final SalesAddressController salesAddressController = Get.put(SalesAddressController()); 
//   List<bool> addButtonClicked = List.filled(productList.length, false);
//   bool showIncrementDecrement = false;
//   List<bool> showIncrementDecrementList = List.generate(
//     productList.length,
//     (index) => false,
//   );

//   List<int> quantityList = List.filled(productList.length, 1);

//   void _incrementQuantity(int index) {
//     setState(() {
//       quantityList[index]++;
//     });
//   }

//   void _decrementQuantity(int index) {
//     setState(() {
//       if (quantityList[index] > 1) {
//         quantityList[index]--;
//       } else {
//         showIncrementDecrementList[index] = false;
//       }
//     });
//   }

//   @override
//   void initState() {
//     super.initState();
//     filteredList.addAll(productList);
//   }

//   void _filterSearchResults(String query) {
//     if (query.isNotEmpty) {
//       setState(() {
//         filteredList = productList
//             .where((product) =>
//                 product['title'].toLowerCase().contains(query.toLowerCase()))
//             .toList();
//       });
//     } else {
//       setState(() {
//         filteredList.clear();
//         filteredList.addAll(productList);
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     // addressController.fetchAddressData('home');
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: Text('Sales'),
//         actions: [
//           Icon(Icons.shopping_cart),
//           SizedBox(
//             width: 10,
//           )
//         ],
//       ),
//       body: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//          Padding(
//   padding: const EdgeInsets.all(16.0),
//   child: Card(
//     child: Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Obx(
//             () {
//               if (salesAddressController.addressList.isNotEmpty) {
//                 return Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       'Name: ${widget.name}',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                     SizedBox(height: 8),
//                     Text(
//                       'Number: ${widget.number}',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                     SizedBox(height: 8),
//                     Text(
//                       'Address Type: Home', 
//                       style: TextStyle(fontSize: 16),
//                     ),
//                     SizedBox(height: 8),
//                     Text(
//                       'Address: ${salesAddressController.addressList.first.address}',
//                       style: TextStyle(fontSize: 16),
//                     ),
//                   ],
//                 );
//               } else {
//                 return Text(
//                   'No address available for the selected type',
//                   style: TextStyle(fontSize: 16),
//                 );
//               }
//             },
//           ),
//         ],
//       ),
//     ),
//   ),
// ),

//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: TextField(
//               controller: _searchController,
//               onChanged: _filterSearchResults,
//               decoration: InputDecoration(
//                 hintText: 'Search by product name',
//                 labelText: 'Search',
//                 border: OutlineInputBorder(),
//               ),
//             ),
//           ),
//           Expanded(
//             child: SingleChildScrollView(
//               child: Column(
//                 children: filteredList.map((product) {
//                   final index = filteredList.indexOf(product);
//                   final showIncrementDecrement =
//                       showIncrementDecrementList[index];
//                   final quantity = quantityList[index];
//                   return Card(
//                     elevation: 5,
//                     margin: EdgeInsets.all(10),
//                     child: Column(
//                       children: [
//                         ListTile(
//                           leading: Image.asset(product['imagePath']),
//                           title: Text(product['title']),
//                           subtitle: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text(product['store']),
//                               _buildStarRating(product['rating']),
//                               SizedBox(height: 5),
//                               Row(
//                                 children: [
//                                   Text(
//                                     product['price'],
//                                     style: TextStyle(color: Colors.black),
//                                   ),
//                                   SizedBox(width: 5),
//                                   Text(
//                                     product['discountedPrice'],
//                                     style: TextStyle(
//                                       color: Colors.grey,
//                                       decoration: TextDecoration.lineThrough,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                           trailing: showIncrementDecrement
//                               ? Row(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     IconButton(
//                                       onPressed: () =>
//                                           _decrementQuantity(index),
//                                       icon: const Icon(Icons.remove),
//                                       color: Colors.black,
//                                     ),
//                                     Text(
//                                       quantity.toString(),
//                                       style: const TextStyle(fontSize: 16),
//                                     ),
//                                     IconButton(
//                                       onPressed: () =>
//                                           _incrementQuantity(index),
//                                       icon: const Icon(Icons.add),
//                                       color: Colors.black,
//                                     ),
//                                   ],
//                                 )
//                               : ElevatedButton(
//                                   onPressed: () {
//                                     setState(() {
//                                       showIncrementDecrementList[index] =
//                                           !showIncrementDecrementList[index];
//                                     });
//                                   },
//                                   child: Text('ADD'),
//                                 ),
//                         ),
//                       ],
//                     ),
//                   );
//                 }).toList(),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// void main() {
//   runApp(MaterialApp(
//     home: Sales_screen(),
//   ));
// }

