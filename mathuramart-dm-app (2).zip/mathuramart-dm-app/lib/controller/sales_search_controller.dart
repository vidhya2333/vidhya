import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../data/model/response/sales_search_model.dart';
import '../util/app_constants.dart';

class SalesSearchController extends GetxController {
  final TextEditingController searchController = TextEditingController();
  Rx<SalesSearchModel?> searchResult = Rx<SalesSearchModel?>(null);

  Future<void> searchByName(String phoneNumber) async {
    try {
      print('Searching for phone number: $phoneNumber');

      if (phoneNumber.isEmpty) {
        throw Exception('Phone number is empty');
      }

      final response = await http.post(
        Uri.parse('${AppConstants.baseUrl}${AppConstants.salesSearchScreenUri}'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode({'phone_number': phoneNumber}),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = json.decode(response.body);
        searchResult.value = SalesSearchModel.fromJson(jsonResponse);
        print('Search successful: $jsonResponse');
      } else {
        throw Exception('Failed to load data: ${response.statusCode}');
      }
    } catch (e) {
      print('Error during search: $e');
      searchResult.value = null;
    }
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}