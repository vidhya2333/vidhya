import 'package:flutter/material.dart';

class search_screen extends StatefulWidget {
  @override
  _search_screenState createState() => _search_screenState();
}

class _search_screenState extends State<search_screen> {
  final Map<String, String> contactData = {
    '1234567890': 'John Doe',
    '9876543210': 'Jane Smith',
    '1112223333': 'Alice Johnson',
    '4445556666': 'Bob Brown',
    '7778889999': 'Carol Davis',
  };

  String? searchedContactNumber;
  String? contactName;

  void searchContactName(String? number) {
    setState(() {
      searchedContactNumber = number;
      contactName = contactData[number ?? ''];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contact Search'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              onChanged: (value) {
                searchContactName(value);
              },
              decoration: InputDecoration(
                hintText: 'Enter a contact number',
                labelText: 'Contact Number',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            Text(
              searchedContactNumber != null
                  ? contactName ?? 'Contact name not found'
                  : 'Enter a contact number to search',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
