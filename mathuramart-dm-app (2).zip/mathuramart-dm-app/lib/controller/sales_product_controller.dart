import 'dart:convert';
import 'dart:developer';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:mathura_mart_dman/data/model/response/sales_product_model.dart';
import 'package:mathura_mart_dman/util/app_constants.dart';

class ProductController extends GetxController {
  var productList = <ProductModel>[].obs;

  @override
  void onInit() {
    fetchProducts();
    super.onInit();
  }

  Future<void> fetchProducts() async {
    try {
      var response = await http.get(Uri.parse(
          '${AppConstants.baseUrl}${AppConstants.salesProductScreenUri}'));
      if (response.statusCode == 200) {
        log('${response.body}');
        var encodedString = jsonEncode(response.body);
        var jsonResponse = json.decode(encodedString);
        List<ProductModel> products = productModelFromJson(jsonResponse);
        productList.assignAll(products);
      } else {
        throw Exception('Failed to load products');
      }
    } catch (e) {
      print('Error fetching products: $e');
    }
  }
}

