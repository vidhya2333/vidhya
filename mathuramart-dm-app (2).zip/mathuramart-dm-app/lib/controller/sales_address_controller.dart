// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:get/get.dart';
// import 'dart:convert';
// import '../data/model/response/address_model.dart';
// import '../util/app_constants.dart';

// class AddressController extends GetxController {
//   RxList<AddressModel> addressList = <AddressModel>[].obs;

//   Future<void> fetchAddressData() async {
//     try {
//       final response = await http.get(
//         Uri.parse('${AppConstants.baseUrl}${AppConstants.salesAddresScreenUri}'),
//         headers: {'Content-Type': 'application/json'},
//       );

//       if (response.statusCode == 200) {
//         List<dynamic> responseData = json.decode(response.body);
//         List<AddressModel> allAddresses = responseData.map((data) => AddressModel.fromJson(data)).toList();
//         addressList.assignAll(allAddresses);
//       } else {
//         throw Exception('Failed to load address data');
//       }
//     } catch (e) {
//       throw Exception('Error: $e');
//     }
//   }

//   Future<void> fetchAddressDataByName(String name) async {
//     try {
//       final response = await http.get(
//         Uri.parse('${AppConstants.baseUrl}${AppConstants.salesAddresScreenUri}?name=$name'),
//         headers: {'Content-Type': 'application/json'},
//       );

//       if (response.statusCode == 200) {
//         List<dynamic> responseData = json.decode(response.body);
//         List<AddressModel> allAddresses = responseData.map((data) => AddressModel.fromJson(data)).toList();
//         addressList.assignAll(allAddresses);
//       } else {
//         throw Exception('Failed to load address data');
//       }
//     } catch (e) {
//       throw Exception('Error: $e');
//     }
//   }
// }
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'dart:convert';
import '../data/model/response/address_model.dart';
import '../util/app_constants.dart';

class AddressController extends GetxController {
  RxList<AddressModel> addressList = <AddressModel>[].obs;

  Future<void> fetchAddressData() async {
    try {
      final response = await http.get(
        Uri.parse(
            '${AppConstants.baseUrl}${AppConstants.salesAddresScreenUri}'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        List<dynamic> responseData = json.decode(response.body);
        List<AddressModel> allAddresses =
            responseData.map((data) => AddressModel.fromJson(data)).toList();
        addressList.assignAll(allAddresses);
      } else {
        throw Exception('Failed to load address data');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<void> fetchAddressDataByName(int name) async {
    try {
      final response = await http.get(
        Uri.parse(
            '${AppConstants.baseUrl}${AppConstants.salesAddresScreenUri}?id=$name'),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        List<dynamic> responseData = json.decode(response.body);
        List<AddressModel> allAddresses =
            responseData.map((data) => AddressModel.fromJson(data)).toList();
        addressList.assignAll(allAddresses);
      } else {
        throw Exception('Failed to load address data');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}

