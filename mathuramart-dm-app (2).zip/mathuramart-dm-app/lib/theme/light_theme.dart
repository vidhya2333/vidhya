import 'package:flutter/material.dart';

ThemeData light = ThemeData(
  useMaterial3: false,
  fontFamily: 'Roboto',
  primaryColor: const Color.fromARGB(255, 18, 132, 177),
  secondaryHeaderColor: Color.fromARGB(255, 91, 183, 219),
  disabledColor: const Color(0xFFA0A4A8),
  brightness: Brightness.light,
  hintColor: const Color(0xFF9F9F9F),
  cardColor: Colors.white,
  textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: const Color.fromARGB(255, 18, 132, 177))),
  colorScheme: const ColorScheme.light(primary:  Color.fromARGB(255, 18, 132, 177), secondary: Color.fromARGB(255, 91, 183, 219)).copyWith(error: const Color(0xFFE84D4F)),
);