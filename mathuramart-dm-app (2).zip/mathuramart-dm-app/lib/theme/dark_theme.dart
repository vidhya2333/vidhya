import 'package:flutter/material.dart';

ThemeData dark = ThemeData(
  useMaterial3: false,
  fontFamily: 'Roboto',
  primaryColor: const Color.fromARGB(255, 91, 189, 228),
  secondaryHeaderColor: Color.fromARGB(255, 52, 178, 228),
  disabledColor: const Color(0xFF6f7275),
  brightness: Brightness.dark,
  hintColor: const Color(0xFFbebebe),
  cardColor: Colors.black,
  textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: const Color.fromARGB(255, 46, 169, 218))),
  colorScheme: const ColorScheme.dark(primary: Color.fromARGB(255, 45, 172, 223), secondary: Color.fromARGB(255, 45, 172, 223)).copyWith(error: const Color(0xFFdd3135)),
);
